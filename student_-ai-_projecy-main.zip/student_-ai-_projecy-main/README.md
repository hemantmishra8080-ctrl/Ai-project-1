# AI PROJECTS 

Beginner project 
